# Packzy Rider Pro — Android Studio Project

এই প্রজেক্টটি `https://dash.packzy.com/rider`-এর একটি Android WebView wrapper।
এটি Packzy ওয়েবসাইটে কোনো পরিবর্তন করে না; একই ওয়েব পোর্টাল অ্যাপের মধ্যে খোলে।

## কী আছে
- Full-screen WebView
- JavaScript ও DOM storage
- Android camera permission request এবং HTTPS Packzy origin-এর জন্য camera capture permission
- ওয়েবসাইটের file upload chooser
- Back button navigation

## কী নেই / গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি এখনো তৈরি করা APK নয়; Android Studio দিয়ে build করতে হবে।
- Packzy-এর নিজস্ব Face Verification, parcel scanning, OTP, login বা API-র বিকল্প এখানে তৈরি করা হয়নি। ওয়েবসাইটে যে ফিচারগুলো আপনার অ্যাকাউন্টে সমর্থিত, সেগুলোই কাজ করবে।
- Packzy-এর অনুমতি ছাড়া private API, authentication bypass বা hidden endpoints ব্যবহার করা হয়নি।
- Camera কাজ করবে কেবল তখনই, যখন Packzy portal-এর ওয়েব পেজ WebView camera capture সমর্থন করে এবং Android permission দেয়।
- Production release-এর আগে Packzy-এর অনুমতি, তাদের supported browser/WebView compatibility, privacy policy ও security review নিশ্চিত করুন।

## APK বানানোর ধাপ
1. Android Studio-তে এই project folder খুলুন।
2. Gradle sync সম্পন্ন করুন।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
4. Build সফল হলে Android Studio-র APK location থেকে নিজের ফোনে install করুন।

## নিরাপত্তা
নিজের Rider account দিয়েই login করুন। Password বা OTP কাউকে দেবেন না। এই project-এ password সংরক্ষণ করা হয় না।
